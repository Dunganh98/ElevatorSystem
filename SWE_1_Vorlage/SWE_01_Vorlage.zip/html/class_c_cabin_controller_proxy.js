var class_c_cabin_controller_proxy =
[
    [ "CCabinControllerProxy", "class_c_cabin_controller_proxy.html#ac1996d6870a806c783349320be6a6c22", null ],
    [ "CSystemController", "class_c_cabin_controller_proxy.html#a0d528668bae06515e5247380db851fa5", null ],
    [ "m_pCabinController", "class_c_cabin_controller_proxy.html#a5d4ab049d3facc88b9f6bc121a2f9d1b", null ]
];