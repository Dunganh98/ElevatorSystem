var _c_simulator_8h =
[
    [ "CSimulator", "class_c_simulator.html", "class_c_simulator" ],
    [ "LABOR1_VOR", "_c_simulator_8h.html#aae2c59bb26e2f8f4cb864ce3fe50e6c9", null ],
    [ "MAXRECV", "_c_simulator_8h.html#a4840306e95bc3cd5760cc6ee5d019cae", null ],
    [ "RUN_LOCAL_CLIENT", "_c_simulator_8h.html#a690d4aa52394caf81a4d2e6f6dfd04e1", null ],
    [ "TCP_PORT", "_c_simulator_8h.html#a637b73f06ee87043251d022f87a8f3d4", null ],
    [ "TIMEOUT_SEC", "_c_simulator_8h.html#ae36ab367e754e8a46e3f5c72060ede8e", null ]
];