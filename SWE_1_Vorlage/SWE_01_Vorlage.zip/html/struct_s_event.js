var struct_s_event =
[
    [ "m_additionalInfo", "struct_s_event.html#a874af180972ec77125f62a3827bce6e4", null ],
    [ "m_eventType", "struct_s_event.html#af40eab45facace6824fbae491844f1e9", null ]
];