var searchData=
[
  ['tcp_5fport',['TCP_PORT',['../_c_simulator_8h.html#a637b73f06ee87043251d022f87a8f3d4',1,'CSimulator.h']]],
  ['timeout_5fsec',['TIMEOUT_SEC',['../_c_simulator_8h.html#ae36ab367e754e8a46e3f5c72060ede8e',1,'CSimulator.h']]]
];
