var searchData=
[
  ['undefined',['UNDEFINED',['../_s_event_8h.html#aacea4a7e80c7ca11553910c740986045a605159e8a4c32319fd69b5d151369d93',1,'SEvent.h']]]
];
