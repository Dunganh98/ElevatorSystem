var indexSectionsWithContent =
{
  0: "acdefghiklmnopqrstuw",
  1: "cs",
  2: "ces",
  3: "acdeghilmoprsuw",
  4: "chimnrstw",
  5: "ces",
  6: "cdefiklmnqrstu",
  7: "c",
  8: "lmrtu",
  9: "kl"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "related",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Friends",
  8: "Macros",
  9: "Pages"
};

