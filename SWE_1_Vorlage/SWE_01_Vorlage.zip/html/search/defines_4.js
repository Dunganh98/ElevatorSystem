var searchData=
[
  ['update_5fperiod_5fms',['UPDATE_PERIOD_MS',['../_c_time_8h.html#a4e8e7d6fdd1f5c6f8a0f341e4b61f025',1,'CTime.h']]]
];
