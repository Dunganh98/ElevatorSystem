var searchData=
[
  ['motor_5fstarts_5frunning',['MOTOR_STARTS_RUNNING',['../_s_event_8h.html#aacea4a7e80c7ca11553910c740986045a6455c1053a20da29f8c2e15b863398fb',1,'SEvent.h']]],
  ['motor_5fstopped',['MOTOR_STOPPED',['../_s_event_8h.html#aacea4a7e80c7ca11553910c740986045a02c50778bea0b18671e7d446647c788a',1,'SEvent.h']]]
];
