var _c_time_8h =
[
    [ "CTime", "class_c_time.html", "class_c_time" ],
    [ "UPDATE_PERIOD_MS", "_c_time_8h.html#a4e8e7d6fdd1f5c6f8a0f341e4b61f025", null ]
];