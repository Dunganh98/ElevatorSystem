/** \file CElevatorSystem.cpp
 * \brief CElevatorSystem class source file.
 * \details Enthaelt die Implementierung der Klasse CElevatorSystem.
 * \author Reimund
 * \date 2016
 */

#include "CElevatorSystem.h"
#include <iostream>


/*! \fn CElevatorSystem::CElevatorSystem(unsigned short numFloors)
 *  \brief Konstruktor; Legt die Anzahl der Stockwerke fuer das Aufzugsystem fest.
 *   MAX_FLOORS darf nicht ueberschritten und 2 nicht unterschritten werden
 */
CElevatorSystem::CElevatorSystem(unsigned short numFloors)
{
    if(numFloors>MAX_FLOORS)
    {
        std::cerr << "ERROR: CElevatorSystem(...): Max amount of floors is " << MAX_FLOORS
        	<< ", set to that\n" << std::flush;
        numFloors=MAX_FLOORS;
    }
    if(numFloors<2)
    {
    	std::cerr << "ERROR: CElevatorSystem(...): Min amount of floors is 2, set to that\n"
    		<< std::flush;
    	numFloors=2;
    }
    m_numFloors=numFloors;
}

/*! \fn void CElevatorSystem::addElevator()
 *  \brief Fuegt dem Aufzugsystem einen Aufzug 
 *   hinzu und verbindet den Systemcontroller mit dem hinzugekommenen Aufzugcontroller
 */
void CElevatorSystem::addElevator()
{
	if((m_cabins.size()+1) <= MAX_ELEVATORS)
	{
		CCabin newCabin;
		m_cabins.push_back(newCabin);
		m_cabins.back().setup();
		m_systemController.connectCabinController(m_cabins.back().cabinControllerProxy());
	}
	else
	{
		std::cerr << "ERROR: CElevatorSystem::addElevator() Max amount of elevators reached ("
		<< MAX_ELEVATORS << ")\n" << std::flush;
	}
	return;
}
