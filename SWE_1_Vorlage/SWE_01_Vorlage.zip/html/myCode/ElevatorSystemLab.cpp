/** \file ElevatorSystemLab.cpp
 * \brief Hauptprogramm mit Programmeinstiegspunkt main().
 * \author Reimund
 * \date 2016
 */

#include <iostream>
#include "simulation/CSimulator.h"
#include "elevatorSystem/CElevatorSystem.h"

using namespace std;

/*! \mainpage Labor Software Engineering: Dokumentation des Aufzugsystems
 * Erstellt von: <br>
 * Le, Thi Thu Giang <br>
 * Pham, Huynh Dung Anh <br>
 * <br>
 * <a href="anforderungen.htm"><b>Anforderungsdokument</b></a><br>
 * <a href="tests.htm"><b>Testdokument</b></a><br>
 * <a href="textantworten.txt"><b>Textantworten</b></a> auf Fragen aus Vorbereitung und Durchfuehrung<br>
 * <br>
 *  \image html Cover.png
 */

/*! \fn int main()
 *  \brief Hauptprogramm.
 *  \details Es wird ein Aufzugsystem definiert: Deklaration des Aufzugsystems,
 *   Hinzufuegen der Kabinen; Anschliessend wird ein
 *   Simulator deklariert und mit dem Aufzugsystem verbunden.
 *   Schliesslich wird die Simulation gestartet.
 */
int main()
{
    // Start
    cout << "ElevatorSystemLab" << endl;
    cout << "=================" << endl << endl;

    // Aufzugsystem definieren
    CElevatorSystem elevatorSystem(5);
    elevatorSystem.addElevator();
    elevatorSystem.addElevator();
    elevatorSystem.addElevator();

    // Simulation definieren, verbinden, und, falls gewollt, Passagiere hinzufuegen
    CSimulator simulator(&elevatorSystem);

    // Simulation starten
    simulator.run();

    cout << ">>> Simulator returned from run(), return 0." << endl;
    return 0;
}

/*! \page Klassendiagramm Klassendiagramm
 *  \image html Aktivitaetdiagram.png Aktivitaetdiagramm
 *  \brief Vorbereitung Aufgabe 1.2 e. Hier wird die Methode run() des Objekts Simualtion
 *   in Aktivitaetdiagram beschreiben
 *
 *  \brief Durchfuhrung Aufgabe 2.3 Hier wird alle Klasse des Objekts ElevatorSystem
 *   in Klassendiagramm beschreiben
 *  \image html Klassendiagram.png Klassendiagramm
 *
 *  \brief Durchfuhrung Aufgabe 2.2 Hier wird Akteur als Passagiere und das Aufzugsystem
 *   in Use-Case Diagramm beschreiben
 *  \image html UsecaseDiagram.png Use-Case Diagramm
 *
 */
