/** \file CCabin.cpp
 * \brief CCabin class source file.
 * \details Enthaelt die Implementierung der Klasse CCabin.
 * \author Reimund
 * \date 2016
 */

#include "CCabin.h"


/*! \fn CCabin::CCabin()
 *  \brief Konstruktor. Belegt die Attribute mit Standardwerten (0, false)
 */
CCabin::CCabin()
{
    m_height = 0.0;
    m_isDriving=false;
    m_load=0.0;
}

/*! \fn void CCabin::setup()
 *  \brief Verbindet die kabineninternen Sensoren und Aktoren mit dem Kabinencontroller und den
 *   physikalischen Groessen der Kabine (z. B. Hoehensensor mit der Kabinenhoehe usw.) und
 *   verbindet im Gegenzug den Kabinencontroller mit den Sensoren und Aktoren. 
 */
void CCabin::setup()
{
    m_heightSensor.connect(&m_cabinController, &m_height);
    m_motor.connect(&m_cabinController, &m_height,  &m_isDriving);
    m_timer.connect(&m_cabinController);
    m_cabinController.connectHeightSensor(&m_heightSensor);
    m_cabinController.connectMotor(&m_motor);
    m_cabinController.connectTimer(&m_timer);
}

/*! \fn CCabinControllerProxy CCabin::cabinControllerProxy()
 *  \brief Gibt ein Proxy-Objekt zurueck, das dem Systemcontroller gestattet,
 *  auf den Kabinencontroller zuzugreifen
 *  \return Ein Kabinencontroller-Proxy
 */
CCabinControllerProxy CCabin::cabinControllerProxy()
{
	return CCabinControllerProxy(&m_cabinController);
}
