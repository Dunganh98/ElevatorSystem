/** \file CCabinController.h
 * \brief CCabinController class header file.
 * \details Enthaelt die Deklaration der Klasse CCabinController.
 * \author Reimund
 * \date 2016
 */

#ifndef CABINCONTROLLER_H_
#define CABINCONTROLLER_H_

#include "CEventQueue.h"


class CSystemController;
class CMotor;
class CTimer;
class CHeightSensor;

/*! \class CCabinController
 * \brief Modelliert einen Kabinencontroller. Er ist verbunden mit den Komponenten
 *  der Kabine. Er steuert diese an, kann ihren Zustand abfragen und erhaelt Events
 *  von diesen. Er beherbergt die aufzugspezifische Zustandssteuerung.
 */
class CCabinController
{
	friend class CSimulator; /**< Simulator hat Vollzugriff auf private-Sektion
		dieser Klasse */

public:
    CCabinController();

    void connectSystemController(CSystemController* pSystemController);
    void connectTimer(CTimer* pTimer);
    void connectMotor(CMotor* pMotor);
    void connectHeightSensor(CHeightSensor* pHeightSensor);

    void driveToFloor(unsigned short destinationFloorNumber);
    unsigned int currentFloor();

    void pushEvent(SEvent event);
    void work();

private:
    enum STATE_TYPE 	// Zustand-Typen des Aufzugs
    {
    	IDLE, 			// warten
    	DRIVING 		// fahren
    };
    CSystemController* m_pSystemController; 			/**< Pointer auf den uebergeordneten Systemcontroller */
    CMotor* m_pMotor; 									/**< Pointer auf den Motor */
    CTimer* m_pTimer; 									/**< Pointer auf den Timer */
    CHeightSensor* m_pHeightSensor;						/**< Pointer auf den Hoehensensor */

    CEventQueue m_eventQueue;							/**< Queue der aufgelaufenen Events */
    STATE_TYPE m_controllerState;						/**< Zustand des Aufzug */
    bool hochfahren;									/**< Fahrrichtung*/
};


#endif /* CABINCONTROLLER_H_ */
