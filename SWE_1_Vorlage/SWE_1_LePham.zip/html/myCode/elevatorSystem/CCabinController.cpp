/** \file CCabinController.cpp
 * \brief CCabinController class source file.
 * \details Enthaelt die Implementierung der Klasse CCabinController.
 * \author Reimund
 * \date 2016
 */
#include "iostream"
#include "CCabinController.h"
#include "CSystemController.h"

#include "CMotor.h"
#include "CTimer.h"
#include "CHeightSensor.h"


/*! \fn void CCabinController::work()
 *  \brief Laesst den Kabinencontroller einen Simulationsschritt
 *   weiterarbeiten. Hier ist der Zustandsautomat fuer den einzelnen Aufzug
 *   zu implementieren. Die Methode wird periodisch durch den Simulator aufgerufen
 */
void CCabinController::work()
{
	bool valid = true;
	connectTimer(m_pTimer);
	SEvent neuesEvent;							// lokale Variable um neues Event zu speichern
	m_pTimer->set(0);							// Timer erst setzen, damit eine Event Timer geworfen ist
	neuesEvent = m_eventQueue.popEvent(&valid);	// pop up die letzte(neues) Event in Eventqueue und speichern in neuesEvent
	if(valid)
	{
	switch(m_controllerState)					// Zustand des Controller pruefen
	{
	  case IDLE:								// wenn Zustand des Controller ist warten
		switch(neuesEvent.m_eventType)			// Event type von neuesEvent pruefen
	    {
			case TIMER:							// Wenn Timer abgelaufen ist
			  m_controllerState = DRIVING;		// Controller wechseln sein Zustand zu fahren
			  if(hochfahren)					// Wenn fahrichtung ist nach oben
				  driveToFloor(3);				// nach 3.Stockwerk fahren
			  else
			  {
				  driveToFloor(0);				// nach Erdgeschoss fahren
			  }
			  break;
			default:
			  break;
	    }
	  break;

	 case DRIVING:								// wenn Zustand des Controller ist fahren
	    switch(neuesEvent.m_eventType)			// Event type von neuesEvent pruefen
	    {
	   	    case MOTOR_STOPPED:					// Wenn Motor gestoppt hat
	   	      m_pTimer->set(3000);				// set Timer to 3s
	   	      hochfahren = !hochfahren;			// fahrichtung nach unten
	   	      m_controllerState = IDLE;			// Controller wechseln sein Zustand zu warten
	   	      break;
	   	    default:
	   		  break;
	    }
	    break;
	 default:
	   break;
	}
	}
}

/*! \fn CCabinController::CCabinController()
 *  \brief Konstruktor; Belegt alle Attribute mit Standardwerten (0, false), die Pointer
 *   mit 0 
 */
CCabinController::CCabinController()
{
	m_pMotor = 0;
	m_pTimer = 0;
	m_pHeightSensor = 0;
	m_pSystemController = 0;
	m_controllerState = IDLE;
	hochfahren = true;
}

/*! \fn void CCabinController::connectSystemController(CSystemController* pSystemController)
	\brief Verbindet den Kabinencontroller mit dem Systemcontroller
	\param pSystemController Pointer auf den zu verbindenden Systemcontroller
 */
void CCabinController::connectSystemController(CSystemController* pSystemController)
{
	m_pSystemController = pSystemController;
}

/*! \fn void CCabinController::connectHeightSensor(CHeightSensor* pHeightSensor)
	\brief Verbindet den Kabinencontroller mit dem Hoehensensor
	\param pHeightSensor Pointer auf den Hoehensensor
 */
void CCabinController::connectHeightSensor(CHeightSensor* pHeightSensor)
{
	m_pHeightSensor = pHeightSensor;
}

/*! \fn void CCabinController::connectMotor(CMotor* pMotor)
	\brief Verbindet den Kabinencontroller mit dem Motor
	\param pMotor Pointer auf den zu verbindenden Motor
 */
void CCabinController::connectMotor(CMotor* pMotor)
{
	m_pMotor=pMotor;
}

/*! \fn void CCabinController::connectTimer(CTimer* pTimer)
	\brief Verbindet den Kabinencontroller mit dem Timer
	\param pTimer Pointer auf den zu verbindenden Timer
 */
void CCabinController::connectTimer(CTimer* pTimer)
{
	m_pTimer=pTimer;
}

/*! \fn void CCabinController::driveToFloor(unsigned short destinationFloorNumber)
	\brief Veranlasst die Kabine, das angegebene Stockwerk anzufahren
	\param destinationFloorNumber Stockwerknummer, die angefahren werden soll
 */
void CCabinController::driveToFloor(unsigned short destinationFloorNumber)
{
	float meters_diff = ((m_pHeightSensor->metersPerFloor())*(destinationFloorNumber)) - m_pHeightSensor->height();
	m_pMotor->lift(meters_diff);
	return;
}

/*! \fn unsigned int CCabinController::currentFloor()
	\brief Liefert die der Kabine naechstgelegene Stockwerknummer zurueck
	\return Die der Kabine naechstgelegene Stockwerknummer
 */
unsigned int CCabinController::currentFloor()
{
	return m_pHeightSensor->currentFloor();
}

/*! \fn void CCabinController::pushEvent(SEvent event)
	\brief Fuegt dem Kabinencontroller ein Event hinzu
	\param event Das hinzuzufuegende Event
 */
void CCabinController::pushEvent(SEvent event)
{
	printEvent(event, (void*)this);
	m_eventQueue.pushEvent(event);
}
