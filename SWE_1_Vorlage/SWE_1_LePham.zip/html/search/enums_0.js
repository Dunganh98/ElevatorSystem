var searchData=
[
  ['client_5faction_5ftype',['CLIENT_ACTION_TYPE',['../class_c_simulator.html#ab1273fb2a18732bc2f21136feb4690d8',1,'CSimulator']]]
];
