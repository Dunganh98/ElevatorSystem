var searchData=
[
  ['new_5fsocket',['new_socket',['../class_c_simulator.html#acd8762b098af50eb26744ab6ee80998e',1,'CSimulator']]]
];
