var searchData=
[
  ['get',['get',['../class_c_time.html#a2a64a5ece54c1d9b05c2c08a91f83566',1,'CTime']]],
  ['get_5fms',['get_ms',['../class_c_time.html#ab40d96388f290e4ba08ae22ae7ae0b5e',1,'CTime']]]
];
