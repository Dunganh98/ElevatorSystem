var NAVTREEINDEX1 =
{
"index.html":[],
"pages.html":[],
"struct_s_event.html":[2,0,11],
"struct_s_event.html#a874af180972ec77125f62a3827bce6e4":[2,0,11,0],
"struct_s_event.html#af40eab45facace6824fbae491844f1e9":[2,0,11,1]
};
