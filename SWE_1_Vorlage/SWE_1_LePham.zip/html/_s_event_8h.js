var _s_event_8h =
[
    [ "SEvent", "struct_s_event.html", "struct_s_event" ],
    [ "EVENT_TYPE", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045", [
      [ "KEY_UP", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045a0848a442d907968b211b97bc2bd88acd", null ],
      [ "KEY_DOWN", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045aa9cdac7967bf7d88fdb761138a2a3416", null ],
      [ "KEY_OPEN_DOORS", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045a31cf7198f99b8f7e0b5dbc340814e438", null ],
      [ "KEY_CLOSE_DOORS", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045ae70f79b352ab73c517fee24b1309ef1b", null ],
      [ "KEY_FLOOR", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045ac9cdb035c2bf03dbd2e955a53ec1cda7", null ],
      [ "KEY_HIGH_PRIORITY", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045a467ec388a8592a0d46b93bd1ec5e7421", null ],
      [ "CABINDOOR_CLOSES", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045a547d5ce4ba8afa984db099824a8b9ca7", null ],
      [ "CABINDOOR_OPENS", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045a02ca8a5587520cb7ea0008befc18c3bc", null ],
      [ "CABINDOOR_FULLY_CLOSED", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045adaf5eb0e1e01e567584928e612e37048", null ],
      [ "CABINDOOR_FULLY_OPEN", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045add97a5d05a74b9c9571f444bb2715a6e", null ],
      [ "ENTRANCEDOOR_CLOSES", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045af222f98af232bf9f874c200a409bdecf", null ],
      [ "ENTRANCEDOOR_OPENS", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045accf1a36774b651ff529503fc84487895", null ],
      [ "ENTRANCEDOOR_FULLY_CLOSED", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045af0cc34a5e7bb75a83d8f54e34f807a09", null ],
      [ "ENTRANCEDOOR_FULLY_OPEN", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045a955572b06a32a0c1db4ebee0a59250ca", null ],
      [ "DOOR_BLOCKED", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045a181397e44ba8064241d501db1864711b", null ],
      [ "DOOR_UNBLOCKED", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045af4c00c688670bbf122a8849f56fe734b", null ],
      [ "REACHED_FLOOR", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045a5d96891211d1256ce94730ae4259cfb3", null ],
      [ "MOTOR_STARTS_RUNNING", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045a6455c1053a20da29f8c2e15b863398fb", null ],
      [ "MOTOR_STOPPED", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045a02c50778bea0b18671e7d446647c788a", null ],
      [ "TIMER", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045a17ba9bae1b8d7e8d6c12d46ec58e0769", null ],
      [ "FIREALERT", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045a5a3a530f1a3a49a6b568154f158e92fc", null ],
      [ "LOADSENSOR_OVERLOAD_DETECTED", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045a700b02376423d880128380d2012b532a", null ],
      [ "LOADSENSOR_OVERLOAD_RESOLVED", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045a56f5b16bc5e72addc6d2aeea89344cd9", null ],
      [ "UNDEFINED", "_s_event_8h.html#aacea4a7e80c7ca11553910c740986045a605159e8a4c32319fd69b5d151369d93", null ]
    ] ],
    [ "evToStr", "_s_event_8h.html#afe8d5bb1e48d72429f4d28c63cf256df", null ],
    [ "printEvent", "_s_event_8h.html#a9c1bdf019e2f55ec3bc2aee901ded060", null ]
];